try:
    from pyzernikemoment import Zernikemoment
except ImportError:
    from pyzernikemoment.pyzernikemoment import Zernikemoment
